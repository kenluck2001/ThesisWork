from django.contrib import admin
from YAAS.advert.models import Advertisement

#register advertisement model to admin interface
admin.site.register(Advertisement)   
