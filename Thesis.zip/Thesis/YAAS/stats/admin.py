from django.contrib import admin
from YAAS.stats.models import RegisteredUser, OnlineUser, StatBid

admin.site.register(RegisteredUser)  
admin.site.register(OnlineUser) 
admin.site.register(StatBid) 



